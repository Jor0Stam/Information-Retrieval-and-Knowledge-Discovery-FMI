#include <stdint.h>
#include <iostream>
#include <cstdlib>
#include <ctime>

#include "Board.h"


int main() {

   int n;
   std::cin >> n;
   

   std::srand(std::time(nullptr));
   Board board(n);
   
   board.swapRandomize();


   board.solve();
   //board.printBoard();
   
}
