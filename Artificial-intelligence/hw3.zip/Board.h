#pragma once
#include <cstdlib>
#include <ctime>
#include <string.h>
#include <stdint.h>
typedef uint16_t tile;


class Board {
public:
   Board(uint32_t arrSize) :
      arrSize(arrSize),
      arr(new tile[arrSize]),
      blueprint(new tile[arrSize]),
      mainDiagConflicts(new int[2 * arrSize - 1]),
      reverseDiagConflicts(new int[2 * arrSize - 1]),
      horizontalConflicts(new int[arrSize]) {
      
      initialize();
      restart();

      calculateBoardConflicts();
   }

   ~Board() {
      delete [] arr;
      delete [] blueprint;
      delete [] mainDiagConflicts;
      delete [] reverseDiagConflicts;
      delete [] horizontalConflicts;
   }

   void swapRandomize();

   void restart();

   uint32_t getColumnWithMostConflicts() const;
   void calculateBoardConflicts();
   void print() const;
   void printConflicts() const;
   void solve();
   void printBoard() const;


private:
   void initialize();

   void fillHorizontalConflicts();
   void fillDiagsConflicts();

   void printOverallConflicts() const;

   void moveQueen(uint32_t column, uint32_t toRow);
   void removeConflicts(uint32_t column);
   void addConflicts(uint32_t column);
   uint32_t getConflictsForField(uint32_t column, uint32_t row) const;
   uint32_t getConflictsForQueen(uint32_t column) const;
   uint32_t findBestRow(uint32_t column) const;

   uint32_t toMainDiagIndex(uint32_t column, uint32_t row) const;
   uint32_t toRevDiagIndex(uint32_t column, uint32_t row) const;
   tile *arr;
   tile *blueprint;
   int *mainDiagConflicts;
   int *reverseDiagConflicts;
   int *horizontalConflicts;

   uint32_t arrSize;
};
