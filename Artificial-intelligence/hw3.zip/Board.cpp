#include "Board.h"
#include <vector>
#include <climits>
#include <stdio.h>

void swap(tile &a, tile &b) {
   tile c = b;
   b = a;
   a = c;
}
void Board::swapRandomize() {
   std::srand(std::time(nullptr));

   for(int i = 0; i < arrSize; ++i) {
      swap(arr[std::rand() % arrSize],
           arr[std::rand() % arrSize]);
   }
   calculateBoardConflicts();
}

void Board::restart() {
   memcpy(arr, blueprint, arrSize * sizeof(tile));
}

uint32_t Board::toMainDiagIndex(uint32_t column, uint32_t row) const {
   return column - row + arrSize - 1;
}
uint32_t Board::toRevDiagIndex(uint32_t column, uint32_t row) const {
   return column + row;
}

void Board::fillDiagsConflicts() {
   memset(reverseDiagConflicts, 0, (2 * arrSize - 1) * sizeof(int));
   memset(mainDiagConflicts, 0, (2 * arrSize - 1) * sizeof(int));
   for (int i = 0; i < arrSize; ++i) {
      ++mainDiagConflicts[toMainDiagIndex(i, arr[i])];
      ++reverseDiagConflicts[toRevDiagIndex(i, arr[i])];
   }
}

void Board::fillHorizontalConflicts() {
   memset(horizontalConflicts, 0, arrSize * sizeof(int));
   for (int i = 0; i < arrSize; ++i) {
      ++horizontalConflicts[arr[i]];
   }
}

void Board::calculateBoardConflicts() {
   fillHorizontalConflicts();
   fillDiagsConflicts();
}

// assumes there is no queen on that field
uint32_t Board::getConflictsForField(uint32_t column, uint32_t row) const {
   return horizontalConflicts[row] + 
          mainDiagConflicts[toMainDiagIndex(column, row)] +
          reverseDiagConflicts[toRevDiagIndex(column, row)];
}

uint32_t Board::getConflictsForQueen(uint32_t column) const {
   return getConflictsForField(column, arr[column]) - 3;
}


void Board::removeConflicts(uint32_t column) {
   uint32_t row = arr[column];

   --horizontalConflicts[row];
   --mainDiagConflicts[toMainDiagIndex(column, row)];
   --reverseDiagConflicts[toRevDiagIndex(column, row)];
}

void Board::addConflicts(uint32_t column) {
   uint32_t conflictsAdded = 0;
   uint32_t row = arr[column];
   ++horizontalConflicts[row];
   ++mainDiagConflicts[toMainDiagIndex(column, row)];
   ++reverseDiagConflicts[toRevDiagIndex(column, row)];
}

void Board::moveQueen(uint32_t column, uint32_t toRow) {
   removeConflicts(column);
   arr[column] = toRow;
   addConflicts(column);
}


uint32_t Board::getColumnWithMostConflicts() const {
   uint32_t max = getConflictsForQueen(0), maxColumn = 0, currentConflicts;

   std::vector<uint32_t> columnes{maxColumn};
   
   for (int i = 0; i < arrSize; ++i) {
      currentConflicts = getConflictsForQueen(i);
      if (currentConflicts > max) {
         max = currentConflicts;
         maxColumn = i;
         columnes.clear();
         columnes.push_back(i);
      } else if (currentConflicts == max) {
         columnes.push_back(i);
      }
   }

   return columnes[std::rand() % columnes.size()];
}

uint32_t Board::findBestRow(uint32_t column) const {
   uint32_t minConflicts = getConflictsForQueen(column);
   uint32_t startingRow = arr[column];
   uint32_t currentConflicts;

   std::vector<uint32_t> columnes{startingRow};

   for (int i = 0; i < arrSize; ++i) {
      if (i == startingRow)
         continue;

      currentConflicts = getConflictsForField(column, i); 
      if (currentConflicts < minConflicts) {
         minConflicts = currentConflicts;
         columnes.clear();
         columnes.push_back(i);
      } else if (currentConflicts == minConflicts) {
         columnes.push_back(i);
      }
   }

   return columnes[std::rand() % columnes.size()];
}

void Board::solve() {
   uint32_t multiplicator = arrSize < 100 ? 100 - arrSize + 3 : 3;
   uint32_t threshold = multiplicator * arrSize, r = 0, mostConflictsColumn;
   while (true) {
      while(r < threshold) {
         
         mostConflictsColumn = getColumnWithMostConflicts();
         if (getConflictsForQueen(mostConflictsColumn) == 0) {
            printf("FOUNDIT\n");
            printConflicts();
            print();
            return;
         }
         moveQueen(mostConflictsColumn, findBestRow(mostConflictsColumn));
         ++r;
      }

      restart();
      swapRandomize();
      r = 0;
   }
}

void Board::printOverallConflicts() const {
   uint32_t res = 0;

   for (int i = 0; i < arrSize; ++i) {
      res += getConflictsForQueen(i);
   }
   printf("%d\n", res);
}

void Board::printBoard() const{

   for (int i = 0; i < arrSize; ++i) {
      for (int j = 0; j < arrSize; ++j) {
         if (arr[j] == i) {
            printf("X");
         } else {
            printf("-");
         }
      }
      printf("\n");
   }

   for (int i = 0; i < arrSize; ++i) {
      printf("%d ", getConflictsForQueen(i));
   }
   printf("\n");
}

void Board::print() const {
   for (int i = 0; i < arrSize; ++i) {
      printf("%d ", arr[i]);
   }
   printf("\n");
}

void Board::printConflicts() const {
   for (int i = 0; i < arrSize; ++i) {
      printf("%d ", getConflictsForQueen(i));
   }
   printf("\n");
}

void Board::initialize() {
   for (int i = 0; i < arrSize; ++i) {
      blueprint[i] = i;
   }
}
